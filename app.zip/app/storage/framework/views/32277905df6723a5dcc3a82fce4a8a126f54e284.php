<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Create</li>
    </ol>

    <!-- Icon Cards-->

    <div class="col-md-6">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(url('news')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="row ">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="title" id="title" placeholder="Title">
                </div>
            </div>
            <div class="row ">
                <div class="input-group mb-3">
                <textarea rows="10" cols="200" name="desctiption"></textarea>
                </div>
            </div>
            <div class="row ">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Upload</span>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="image_upload" id="inputGroupFile01">
                        <!-- <?php if(auth()->user()->image): ?>
                            <code><?php echo e(auth()->user()->image); ?></code>
                        <?php endif; ?> -->
                        <label class="custom-file-label" name="image" for="inputGroupFile01">Choose file</label>
                    </div>
                </div>
            </div>
            <div class="row ">
                <div class="input-group mb-3">
                    <button class="btn btn-primary" type="submit" style="width:500px;margin-left:80%;">Create</button>
                </div>
            </div><hr>
        </form>
    </div>
        
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>