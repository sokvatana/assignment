<?php $__env->startSection('content'); ?>

<div class="container-fluid">

<!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="#">Dashboard</a>
  </li>
  <li class="breadcrumb-item active">Overview</li>
</ol>

<!-- DataTables Example -->
<div class="card mb-3">
  <div class="card-header">
    <i class="fas fa-table"></i>
    List Overview
    <span style="float:right !important;"><a href="<?php echo e(url('news/create')); ?>"> Create </a></span>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>No</th>
            <th>Title</th>
            <th>Description</th>
            <th>Thumbnail</th>
            <th>Create Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php
            $i = 1;   
        ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

          <tr>
            <td><?php echo e($i++); ?></td>
            <td style="width:350px !important;"><?php echo e($post->title); ?></td>
            <td style="width:700px !important;"><?php echo e(str_limit($post->desctiption, $limit = 200, $end = '...')); ?></td>
            <td><img src="/upload/images/<?php echo e($post->image); ?>" style="width:100px;height:70px;"></td>
            <td><?php echo e($post->created_at); ?></td>
            <td>
            <?php echo Form::open(array('class' => 'form-inline', 'method' => 'DELETE', 'route' => array('news.destroy', $post->id))); ?>

              <?php echo Form::submit('Delete', array('class' => ' btn-danger')); ?>

            <?php echo Form::close(); ?>

            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>