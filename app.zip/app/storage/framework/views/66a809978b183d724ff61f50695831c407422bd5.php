<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
        <div class="page-wrapper">
            <div class="blog-top clearfix">
                <h4 class="pull-left">Recent News <a href="#"><i class="fa fa-rss"></i></a></h4>
            </div><!-- end blog-top -->
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="blog-list clearfix">
                <div class="blog-box row">
                    <div class="col-md-4">
                        <div class="post-media">
                            <a href="<?php echo e(route('news.show', $post->id)); ?>" title="">
                                <img src="/upload/images/<?php echo e($post->image); ?>" alt="" class="img-fluid">
                                <div class="hovereffect"></div>
                            </a>
                        </div><!-- end media -->        
                    </div><!-- end col -->

                    <div class="blog-meta col-md-8">  <!--big-meta-->
                        <h4><a href="<?php echo e(route('news.show', $post->id)); ?>" title=""><?php echo e($post->title); ?></a></h4>
                        <?php echo e(str_limit($post->desctiption, $limit = 150, $end = '...')); ?>

                        <small class="firstsmall"><a class="bg-orange" href="#" title="">Hot News</a></small>
                        <small><a href="#" title=""><?php echo e($post->created_at); ?></a></small>
                    </div><!-- end meta -->
                </div><!-- end blog-box -->
                
                <hr class="invis">

            </div><!-- end blog-list -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- end page-wrapper -->

        <hr class="invis">

    </div><!-- end col -->
</div><!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>