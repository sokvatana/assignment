@extends('layouts.template')

@section('content')

<div class="row">
    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
        <div class="page-wrapper">
            <div class="blog-top clearfix">
                <h4 class="pull-left">Recent News <a href="#"><i class="fa fa-rss"></i></a></h4>
            </div><!-- end blog-top -->
            @foreach($posts as $post)
            <div class="blog-list clearfix">
                <div class="blog-box row">
                    <div class="col-md-4">
                        <div class="post-media">
                            <a href="{{ route('news.show', $post->id) }}" title="">
                                <img src="/upload/images/{{$post->image}}" alt="" class="img-fluid">
                                <div class="hovereffect"></div>
                            </a>
                        </div><!-- end media -->        
                    </div><!-- end col -->

                    <div class="blog-meta col-md-8">  <!--big-meta-->
                        <h4><a href="{{ route('news.show', $post->id) }}" title="">{{$post->title}}</a></h4>
                        {{ str_limit($post->desctiption, $limit = 150, $end = '...') }}
                        <small class="firstsmall"><a class="bg-orange" href="#" title="">Hot News</a></small>
                        <small><a href="#" title="">{{$post->created_at}}</a></small>
                    </div><!-- end meta -->
                </div><!-- end blog-box -->
                
                <hr class="invis">

            </div><!-- end blog-list -->
            @endforeach
        </div><!-- end page-wrapper -->

        <hr class="invis">

    </div><!-- end col -->
</div><!-- end row -->

@endsection