@extends('layouts.admin')

@section('content')

<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Create</li>
    </ol>

    <!-- Icon Cards-->

    <div class="col-md-6">
        @if(count($errors) > 0)
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form method="post" action="{{url('news')}}" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="row ">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="title" id="title" placeholder="Title">
                </div>
            </div>
            <div class="row ">
                <div class="input-group mb-3">
                <textarea rows="10" cols="200" name="desctiption"></textarea>
                </div>
            </div>
            <div class="row ">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Upload</span>
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="image_upload" id="inputGroupFile01">
                        <!-- @if (auth()->user()->image)
                            <code>{{ auth()->user()->image }}</code>
                        @endif -->
                        <label class="custom-file-label" name="image" for="inputGroupFile01">Choose file</label>
                    </div>
                </div>
            </div>
            <div class="row ">
                <div class="input-group mb-3">
                    <button class="btn btn-primary" type="submit" style="width:500px;margin-left:80%;">Create</button>
                </div>
            </div><hr>
        </form>
    </div>
        
</div>

@endsection('content')